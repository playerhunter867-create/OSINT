
const API = localStorage.getItem('osint_api') || 'http://127.0.0.1:8000';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let resources=[], selected='ALL';
async function init(){
  try{
    const r=await fetch(`${API}/api/catalog`); if(!r.ok) throw new Error('Catalog API unavailable');
    const d=await r.json(); resources=d.resources||[];
    $('toolCount').textContent=d.resource_count.toLocaleString();
    $('catCount').textContent=d.category_count.toLocaleString();
    renderCats(d.categories||[]); render();
  }catch(e){$('grid').innerHTML=`<div class="empty">Could not load catalog. Start the API, then reload.<br><small>${esc(e.message)}</small></div>`}
}
function renderCats(cats){
 const box=$('categories');
 box.innerHTML=`<button class="cat active" data-cat="ALL">ALL RESOURCES</button>`+
 cats.map(c=>`<button class="cat" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
 box.querySelectorAll('.cat').forEach(b=>b.onclick=()=>{selected=b.dataset.cat;box.querySelectorAll('.cat').forEach(x=>x.classList.toggle('active',x===b));render()});
}
function render(){
 const q=$('q').value.trim().toLowerCase();
 let list=resources.filter(x=>{
   const hay=[x.name,x.description,x.bestFor,x.input,x.output,...(x.categories||[])].join(' ').toLowerCase();
   return (selected==='ALL'||(x.categories||[]).includes(selected)) && (!q||hay.includes(q));
 });
 if($('sort').value==='status') list.sort((a,b)=>String(a.status).localeCompare(String(b.status))||a.name.localeCompare(b.name));
 else list.sort((a,b)=>a.name.localeCompare(b.name));
 $('empty').hidden=list.length>0;
 $('grid').innerHTML=list.slice(0,500).map(card).join('');
}
function card(x){
 const price=x.pricing?`<span class="badge">${esc(x.pricing)}</span>`:'';
 const status=x.status==='live'?'<span class="badge live">LIVE</span>':`<span class="badge">${esc(x.status||'unknown')}</span>`;
 return `<article class="tool"><div class="tooltop"><h3>${esc(x.name)}</h3>${status}</div>
 <div class="badges">${price}${x.localInstall?'<span class="badge">LOCAL</span>':''}${x.api?'<span class="badge">API</span>':''}</div>
 <p>${esc(x.description||x.bestFor||'No description available.')}</p>
 <div class="toolfoot"><span>${esc(x.category||'Other')}</span>${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">OPEN ↗</a>`:''}</div></article>`;
}
$('q').addEventListener('input',render);
$('sort').addEventListener('change',render);
init();
